# Architecture - Structure Modulaire

## Vue d'ensemble

Le projet Findshop a été restructuré pour éviter la duplication de code. Les composants réutilisables (header et footer) sont maintenant centralisés dans un dossier dédié.

## Structure des dossiers

```
Findshop/
├── components/              # Composants réutilisables
│   ├── header.html         # Navigation commune à toutes les pages
│   └── footer.html         # Pied de page commun
├── css/
│   └── style.css
├── js/
│   ├── components-loader.js # Script qui charge les composants
│   ├── auth.js
│   ├── app.js
│   └── ... (autres scripts)
├── assets/
│   ├── icons/
│   └── images/
└── *.html                  # Pages HTML (index, login, contact, etc.)
```

## Avantages de cette structure

✅ **DRY (Don't Repeat Yourself)** - Le header et footer sont définis une seule fois  
✅ **Maintenance facile** - Une seule modification du header affecte toutes les pages  
✅ **Cohérence** - Toutes les pages ont exactement le même header/footer  
✅ **Performance** - Les composants sont mis en cache par le navigateur  

## Comment ça fonctionne ?

### 1. Composants HTML (`components/`)

Les fichiers HTML dans le dossier `components/` contiennent uniquement le code du header/footer, sans les balises `<html>`, `<head>`, `<body>`.

- **`header.html`** : Navigation, logo, authentification
- **`footer.html`** : Informations légales, liens utiles

### 2. Chargement dynamique (`js/components-loader.js`)

Le script `components-loader.js` :
- Récupère les fichiers `header.html` et `footer.html`
- Les injecte dans les balises `<header>` et `<footer>` vides de chaque page
- Réinitialise les écouteurs d'événements (déconnexion, etc.)
- Déclenche un événement personnalisé `componentsLoaded`

### 3. Pages HTML

Chaque page HTML (index.html, login.html, etc.) :
- Contient maintenant des balises `<header></header>` et `<footer></footer>` vides
- Charge le script `js/components-loader.js` EN PREMIER
- Les composants sont injectés avant l'exécution des autres scripts

## Exemple : Ajouter un nouveau composant

Pour ajouter un nouvel composant réutilisable (par exemple une barre latérale) :

### 1. Créer le fichier du composant
```html
<!-- components/sidebar.html -->
<aside class="sidebar">
  <!-- Contenu de la barre latérale -->
</aside>
```

### 2. Modifier `components-loader.js`
```javascript
async function initializeComponents() {
    await Promise.all([
        loadComponent('header', 'header'),
        loadComponent('footer', 'footer'),
        loadComponent('sidebar', '.sidebar')  // Nouvelle ligne
    ]);
    // ...
}
```

### 3. Ajouter le composant dans les pages
```html
<body>
    <header></header>
    <aside class="sidebar"></aside>  <!-- Nouvelle ligne -->
    <main><!-- ... --></main>
    <footer></footer>
    <script src="js/components-loader.js"></script>
</body>
```

## Notes importantes

⚠️ **Le script `components-loader.js` DOIT être chargé en premier**  
Cela garantit que les composants sont injectés avant l'exécution des scripts d'authentification.

⚠️ **Chemins relatifs**  
Les chemins dans `components-loader.js` sont relatifs à la racine du projet. Assurez-vous que la structure des dossiers reste cohérente.

## Hiérarchie de chargement

```
1. HTML est analysé
2. Script components-loader.js s'exécute
3. Composants (header, footer) sont chargés
4. Autres scripts d'authentification s'exécutent
5. Événement componentsLoaded est déclenché
```

## Tests et validation

Pour vérifier que tout fonctionne correctement :

✓ Ouvrez une page dans le navigateur
✓ Vérifiez que le header et footer apparaissent
✓ Testez les boutons de déconnexion
✓ Vérifiez la console pour les erreurs

## Fichiers modifiés

Les fichiers HTML suivants ont été mis à jour pour utiliser les nouveaux composants :
- ✅ index.html
- ✅ login.html
- ✅ register.html
- ✅ contact.html
- ✅ dashboard.html
- ✅ commerçant.html
- ✅ detail-commerce.html
- ✅ visiteur.html
