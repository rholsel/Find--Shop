# Plan de Sécurité FINDSHOP

## 📋 Résumé du Plan de Sécurité Implémenté

Ce document décrit les trois niveaux de sécurité mis en place pour protéger l'application FINDSHOP.

---

## 🔗 PARTIE 1: Lier le chargement du Header au rôle de l'utilisateur

### Objectif
Afficher un header différent selon le rôle de l'utilisateur (visiteur, commerçant, non-connecté)

### Implémentation

#### Fichier: `js/components-loader.js`

La fonction `getHeaderComponentName()` détecte le rôle de l'utilisateur:

```javascript
function getHeaderComponentName() {
    // Récupère l'utilisateur depuis le localStorage
    const authRaw = localStorage.getItem('findshop_auth');
    
    if (!authRaw) {
        return 'header';  // Utilisateur non connecté
    }
    
    const authUser = JSON.parse(authRaw);
    if (authUser.role === 'merchant') {
        return 'header-merchant';  // Commerçant
    }
    
    return 'header-visitor';  // Visiteur/Client
}
```

#### Composants chargés

| Utilisateur | Component | Fichier |
|------------|-----------|---------|
| Non connecté | Default | `components/header.html` |
| Commerçant | Merchant | `components/header-merchant.html` |
| Visiteur/Client | Visitor | `components/header-visitor.html` |

#### Flux d'initialisation

1. `components-loader.js` charge au démarrage de chaque page
2. Vérifie le localStorage pour l'utilisateur connecté
3. Charge le bon header en fonction du rôle
4. Applique les écouteurs d'événements (déconnexion, etc.)

---

## 🔒 PARTIE 2: Sécuriser les accès aux pages HTML principales

### Objectif
Empêcher les accès non autorisés en redirigeant les utilisateurs vers les pages appropriées

### Pages Protégées

#### 1. `dashboard.html` (Page Commerçant)

**Protection:** `js/dashboard.js`

```javascript
// Seuls les commerçants peuvent accéder au dashboard
if (typeof requireRole === 'function') {
    requireRole('merchant', 'index.html');
}
```

**Comportement:**
- ✅ Commerçant connecté → Accès autorisé
- ❌ Visiteur connecté → Redirection vers `index.html`
- ❌ Non connecté → Redirection vers `index.html`

#### 2. `commerçant.html` (Espace Commerçant)

**Protection:** Script inline dans commerçant.html

```javascript
// Seuls les commerçants peuvent accéder à l'espace commerçant
if (typeof requireRole === 'function') {
    requireRole('merchant', 'index.html');
}
```

**Comportement:**
- ✅ Commerçant connecté → Accès autorisé
- ❌ Visiteur connecté → Redirection vers `index.html`
- ❌ Non connecté → Redirection vers `index.html`

#### 3. `visiteur.html` (Espace Visiteur)

**Protection:** Script inline dans visiteur.html

```javascript
// Si connecté en tant que commerçant → redirection vers dashboard
// Si non-connecté → redirection vers login
const user = getAuthenticatedUser();
if (!user) {
    window.location.href = 'login.html';  // Non connecté
} else if (user.role === 'merchant') {
    window.location.href = 'dashboard.html';  // Commerçant
}
// Visiteur/Client → Accès autorisé
```

**Comportement:**
- ❌ Non connecté → Redirection vers `login.html`
- ❌ Commerçant connecté → Redirection vers `dashboard.html`
- ✅ Visiteur connecté → Accès autorisé

### Fonction de Vérification de Rôle

#### Fichier: `js/auth.js`

```javascript
/**
 * Vérifie que l'utilisateur connecté a le rôle requis
 * @param {string} requiredRole - Le rôle requis ('merchant' ou 'visitor')
 * @param {string} redirectUrl - URL de redirection si le rôle ne correspond pas
 */
function requireRole(requiredRole, redirectUrl = 'index.html') {
    const user = getAuthenticatedUser();
    
    if (!user) {
        // Pas d'utilisateur connecté
        window.location.href = redirectUrl;
        return;
    }
    
    if (user.role !== requiredRole) {
        // Rôle incorrect
        window.location.href = redirectUrl;
        return;
    }
    
    // Accès autorisé
    console.log(`✓ Accès autorisé pour le rôle '${requiredRole}'`);
}
```

---

## 👥 PARTIE 3: Uniformiser les comptes de test

### Objectif
Fournir des comptes de test standardisés pour valider la sécurité du système

### Comptes Disponibles

#### Compte Visiteur
```
Email: visitor@test.com
Mot de passe: test1234
Rôle: visitor
```

#### Compte Commerçant
```
Email: merchant@test.com
Mot de passe: test1234
Rôle: merchant
Boutique: Ma Boutique Test
```

### Initialisation Automatique

#### Fichier: `js/test-accounts.js`

La fonction `initTestAccounts()` est appelée automatiquement au chargement des pages:
- `index.html`
- `login.html`
- `register.html`

**Fonctionnement:**
1. Vérifie si les comptes existent déjà dans localStorage
2. S'ils n'existent pas, les crée automatiquement
3. Hash les mots de passe avec SHA-256
4. Affiche un log de confirmation dans la console

**Appel explicite:**
```javascript
// Créer les comptes de test manuellement
initTestAccounts();

// Afficher les comptes disponibles
showTestAccounts();
```

---

## 🧪 Scénarios de Test

### Scénario 1: Visiteur accédant à dashboard.html
1. Connectez-vous avec `visitor@test.com`
2. Accédez à `/dashboard.html`
3. ✅ Vous êtes redirigé vers `index.html`

### Scénario 2: Commerçant accédant à visiteur.html
1. Connectez-vous avec `merchant@test.com`
2. Accédez à `/visiteur.html`
3. ✅ Vous êtes redirigé vers `dashboard.html`

### Scénario 3: Utilisateur non connecté accédant à une page protégée
1. Accédez à `/dashboard.html` sans être connecté
2. ✅ Vous êtes redirigé vers `index.html`

### Scénario 4: Vérifier les headers par rôle
1. Non connecté → Header par défaut
2. Connecté en tant que visiteur → Header visiteur
3. Connecté en tant que commerçant → Header commerçant

---

## 🔐 Résumé de la Sécurité

| Niveau | Implémentation | Vérification |
|--------|----------------|--------------|
| **Header** | Chargement dynamique selon rôle | ✅ localStorage detection |
| **Pages** | Redirection basée sur `requireRole()` | ✅ Role validation |
| **Test** | Comptes prédéfinis avec rôles | ✅ Auto-initialization |

---

## ⚠️ Limitations et Considérations

1. **Sécurité côté client**: Ce système repose sur JavaScript côté client. Pour une production réelle, ajouter une validation côté serveur.

2. **localStorage**: Les mots de passe sont hashés mais le système est limité au localStorage. Utiliser une API backend en production.

3. **CORS**: Assurer que les fetches de composants sont correctes avec votre serveur.

---

## 📚 Fichiers Modifiés

- ✅ `js/auth.js` - Ajout de `requireRole()`
- ✅ `js/components-loader.js` - Améliorations de détection de rôle
- ✅ `js/dashboard.js` - Vérification merchant
- ✅ `js/test-accounts.js` - Nouveau fichier
- ✅ `commerçant.html` - Vérification merchant
- ✅ `visiteur.html` - Vérification visiteur/redirecation merchant
- ✅ `index.html`, `login.html`, `register.html` - Initialisation des comptes test

---

## 🚀 Prochaines Étapes

1. Tester tous les scénarios ci-dessus
2. Vérifier les logs console (`[Auth]`, `[Header]`, `[TestAccounts]`)
3. Ajouter une API backend pour la persistance sécurisée
4. Implémenter des tokens JWT pour la production
5. Ajouter une validation côté serveur
"