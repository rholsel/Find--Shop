function showAlert(message, type = "success") {

    const alert = document.createElement("div");

    alert.className =
        `fixed top-5 right-5 px-4 py-3 rounded shadow-lg text-white z-50
        ${type === "success"
            ? "bg-green-500"
            : "bg-red-500"}`;

    alert.innerText = message;

    document.body.appendChild(alert);

    setTimeout(() => {
        alert.remove();
    }, 3000);
}