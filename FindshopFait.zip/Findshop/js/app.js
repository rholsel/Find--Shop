let commerces = [];

const container =
    document.getElementById(
        "commerceContainer"
    );

const productContainer = document.getElementById('productContainer');
let products = [];
let currentPage = 1;
let pageSize = 9;
let currentSort = '';
let userLocation = null; // {lat, lon}

async function loadCommerces() {

    try {

        showLoader();

        const response =
            await fetch(
                "./data/commerces.json"
            );

        commerces =
            await response.json();

        // overlay stored commerces (logo/cover/lat/lon)
        try {
            const rawStored = localStorage.getItem('findshop_commerces');
            const storedComms = rawStored ? JSON.parse(rawStored) : [];
            if (Array.isArray(storedComms) && storedComms.length) {
                commerces = commerces.map(c => {
                    const s = storedComms.find(x => x.id === c.id);
                    return s ? { ...c, ...s } : c;
                });
            }
        } catch (e) {
            console.error('Erreur lecture commerces stockés', e);
        }

        hideLoader();

        renderCommerces(commerces);

    }

    catch(error) {

        hideLoader();

        showAlert(
            "Erreur de chargement",
            "error"
        );

        console.error(error);
    }
}

function renderCommerces(data) {

    container.innerHTML = "";

    if(data.length === 0){

        container.innerHTML = `
            <div class="col-span-3 bg-red-100 p-4 rounded">
                Aucun résultat trouvé.
            </div>
        `;

        return;
    }

    data.forEach(item => {

        const card =
            document.createElement("div");

        card.className =
            "bg-white rounded-xl shadow overflow-hidden fade-in";

        const avgRating = typeof getCommerceAverageRating === 'function' ? getCommerceAverageRating(item.id) : null;
        const ratingHtml = avgRating
            ? `<div class="flex items-center gap-2 text-yellow-500 text-sm">${renderStars(avgRating)} <span class="text-gray-600">${avgRating.toFixed(1)}</span></div>`
            : `<div class="text-sm text-gray-500">Pas encore de note</div>`;

        card.innerHTML = `
            <div class="commerce-image-container">
                <img src="${item.image || 'https://picsum.photos/seed/commerce/600/400'}" alt="${item.nom}">
                <a href="detail-commerce.html?id=${item.id}" class="btn-voir-commerce">
                    Voir le commerce
                </a>
            </div>
            <div class="p-5">
                <h3 class="font-bold text-xl">
                    ${item.nom}
                </h3>
                <div class="text-sm text-gray-600 mt-1">${item.quartier} ${renderDistanceForCommerce(item)}</div>
                ${ratingHtml}

                <p class="text-blue-600 mt-1">
                    ${item.categorie}
                </p>

                <p class="mt-3 text-gray-700 text-sm">
                    ${item.description}
                </p>
            </div>
        `;

        container.appendChild(card);
    });

    window.dispatchEvent(new CustomEvent('commerces:rendered', { detail: data }));
}

function renderDistanceForCommerce(item) {
    try {
        if (!userLocation) return '';
        const lat = item.lat || item.latitude || null;
        const lon = item.lon || item.longitude || null;
        if (typeof lat === 'undefined' || typeof lon === 'undefined' || lat === null || lon === null) return '';
        const d = haversine(userLocation.lat, userLocation.lon, Number(lat), Number(lon));
        if (Number.isNaN(d)) return '';
        return `· 📍 ${d.toFixed(1)} km`;
    } catch(e){ return ''; }
}

// Agrège les produits depuis les commerces pour créer un catalogue plat
function buildProductsFromCommerces(commercesList) {
    const list = [];
    commercesList.forEach(c => {
        if (Array.isArray(c.produits)) {
            c.produits.forEach(p => {
                list.push({
                    nom: p.nom,
                    prix: p.prix,
                    commerceId: c.id,
                    commerceNom: c.nom,
                    categorie: c.categorie,
                    quartier: c.quartier,
                    image: p.image || c.image || '',
                    lat: c.lat || c.latitude || null,
                    lon: c.lon || c.longitude || null
                });
            });
        }
    });
    return list;
}

function renderProducts(data) {
    if (!productContainer) return;
    productContainer.innerHTML = '';
    if (!data || data.length === 0) {
        productContainer.innerHTML = `
            <div class="col-span-3 bg-red-100 p-4 rounded">
                Aucun produit trouvé.
            </div>
        `;
        return;
    }

    // apply sorting
    let items = [...data];
    if (currentSort === 'price_asc') items.sort((a,b) => Number(a.prix) - Number(b.prix));
    if (currentSort === 'price_desc') items.sort((a,b) => Number(b.prix) - Number(a.prix));
    if (currentSort === 'name_asc') items.sort((a,b) => (a.nom||'').localeCompare(b.nom||''));
    if (currentSort === 'name_desc') items.sort((a,b) => (b.nom||'').localeCompare(a.nom||''));
    if (currentSort === 'proximity' && userLocation) {
        items.forEach(it => {
            if (!it._distance) {
                const lat = it.lat || it.latitude || null;
                const lon = it.lon || it.longitude || null;
                if (lat != null && lon != null) it._distance = haversine(userLocation.lat, userLocation.lon, Number(lat), Number(lon));
                else it._distance = Infinity;
            }
        });
        items.sort((a,b) => (a._distance||Infinity) - (b._distance||Infinity));
    }

    const totalItems = items.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    if (currentPage > totalPages) currentPage = totalPages;

    const start = (currentPage - 1) * pageSize;
    const pageItems = items.slice(start, start + pageSize);

    if (pageItems.length === 0) {
        productContainer.innerHTML = `
            <div class="col-span-3 bg-red-100 p-4 rounded">
                Aucun produit trouvé sur cette page.
            </div>
        `;
    }

    pageItems.forEach(item => {
        const card = document.createElement('div');
        card.className = 'bg-white rounded-xl shadow p-4 fade-in';
        const favorite = typeof isFavorite === 'function' ? isFavorite(item) : false;
        card.innerHTML = `
            <img src="${item.image || item.commerceImage || 'https://picsum.photos/seed/product/600/400'}" alt="${item.nom}" class="w-full h-40 object-cover rounded">
            <div class="flex justify-between items-start gap-2 mt-3">
                <h4 class="font-semibold">${item.nom}</h4>
                <button type="button" class="favorite-btn text-xl ${favorite ? 'text-red-500' : 'text-gray-400'}" data-product-key="${getProductUniqueKey(item)}">
                    ${favorite ? '♥' : '♡'}
                </button>
            </div>
            <div class="flex items-center justify-between mt-2">
                <div class="text-indigo-600 font-bold">${Number(item.prix).toFixed(2)} $</div>
                <div class="text-sm text-gray-500">${item.categorie} · ${item.quartier || item.commerceQuartier}</div>
            </div>
            <div class="text-sm text-gray-600 mt-1">${renderDistanceForProduct(item)}</div>
            <p class="mt-2 text-gray-600">Boutique: <strong>${item.commerceNom}</strong></p>
            <a href="detail-commerce.html?id=${item.commerceId}" class="inline-block mt-3 bg-blue-600 text-white px-3 py-2 rounded">Voir boutique</a>
        `;

        const favBtn = card.querySelector('.favorite-btn');
        if (favBtn) {
            favBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const toggled = toggleFavorite(item);
                favBtn.textContent = toggled ? '♥' : '♡';
                favBtn.classList.toggle('text-red-500', toggled);
                favBtn.classList.toggle('text-gray-400', !toggled);
                showAlert(toggled ? 'Ajouté aux favoris' : 'Retiré des favoris', 'success');
            });
        }

        productContainer.appendChild(card);
    });

    renderPagination(totalPages);
}

function renderDistanceForProduct(item) {
    try {
        if (!userLocation) return '';
        const lat = item.lat || item.latitude || null;
        const lon = item.lon || item.longitude || null;
        if (typeof lat === 'undefined' || typeof lon === 'undefined' || lat === null || lon === null) return '';
        const d = haversine(userLocation.lat, userLocation.lon, Number(lat), Number(lon));
        if (Number.isNaN(d)) return '';
        return `📍 ${d.toFixed(1)} km`;
    } catch(e){ return ''; }
}

function renderWeeklyTrivia(commerces, products) {
    const container = document.getElementById('weeklyTrivia');
    if (!container) return;
    if (!Array.isArray(commerces) || commerces.length === 0) {
        container.textContent = 'Aucune anecdote disponible cette semaine.';
        return;
    }

    const weekKey = Math.floor(Date.now() / (1000 * 60 * 60 * 24 * 7));
    const index = weekKey % commerces.length;
    const commerce = commerces[index];
    const product = Array.isArray(commerce.produits) && commerce.produits.length > 0 ? commerce.produits[0] : null;

    const suggestions = [];
    if (product && product.nom) {
        suggestions.push(`Le saviez-vous ? Chez ${commerce.nom}, ${product.nom} fait partie des produits les plus appréciés des clients du quartier.`);
        suggestions.push(`Le saviez-vous ? Chez ${commerce.nom}, ${product.nom} attire souvent les habitants qui aiment la qualité locale.`);
    }

    if (commerce.description && commerce.description.toLowerCase().includes('frais')) {
        suggestions.push(`Le saviez-vous ? Chez ${commerce.nom}, les produits frais sont choisis avec soin pour les voisins du quartier.`);
    }

    if (commerce.categorie) {
        if (commerce.categorie.toLowerCase().includes('électronique')) {
            suggestions.push(`Le saviez-vous ? Chez ${commerce.nom}, les petits accessoires de tous les jours sont très demandés par les clients locaux.`);
        }
        if (commerce.categorie.toLowerCase().includes('alimentation')) {
            suggestions.push(`Le saviez-vous ? Chez ${commerce.nom}, les habitants du coin reviennent souvent pour les produits de qualité et l'accueil chaleureux.`);
        }
    }

    if (commerce.lat != null && commerce.lon != null) {
        suggestions.push(`Le saviez-vous ? La carte interactive affiche les commerces géolocalisés : cliquez sur un point pour voir les détails du commerce.`);
    }

    const trivia = suggestions.length > 0 ? suggestions[weekKey % suggestions.length] : `Le saviez-vous ? ${commerce.nom} est un commerce apprécié des habitants du quartier.`;
    container.textContent = trivia;
}

function renderPagination(totalPages) {
    const pager = document.getElementById('pagination');
    if (!pager) return;
    pager.innerHTML = '';

    const prev = document.createElement('button');
    prev.className = 'px-3 py-1 border rounded';
    prev.textContent = '« Prev';
    prev.disabled = currentPage <= 1;
    prev.addEventListener('click', () => { currentPage--; renderProducts(products); });
    pager.appendChild(prev);

    const pageInfo = document.createElement('span');
    pageInfo.className = 'px-3';
    pageInfo.textContent = `${currentPage} / ${totalPages}`;
    pager.appendChild(pageInfo);

    const next = document.createElement('button');
    next.className = 'px-3 py-1 border rounded';
    next.textContent = 'Next »';
    next.disabled = currentPage >= totalPages;
    next.addEventListener('click', () => { currentPage++; renderProducts(products); });
    pager.appendChild(next);
}

// Charge les produits ajoutés par les commerçants depuis localStorage
function loadStoredProducts() {
    try {
        const raw = localStorage.getItem('findshop_products');
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error('Erreur parsing stored products', e);
        return [];
    }
}

function showLoader() {
    const loader = document.getElementById("loader");
    if (loader) {
        loader.classList.remove("hidden");
    }
}

function hideLoader() {
    const loader = document.getElementById("loader");
    if (loader) {
        loader.classList.add("hidden");
    }
}

// Lie la barre de recherche et les filtres à la fonction de filtrage
function bindSearchUI() {
    const searchInput = document.getElementById("searchInput");
    const categoryFilter = document.getElementById("categoryFilter");
    const districtFilter = document.getElementById("districtFilter");

    if (searchInput) searchInput.addEventListener('input', () => { filterCommerces(); filterProducts(); });
    if (categoryFilter) categoryFilter.addEventListener('change', () => { filterCommerces(); filterProducts(); });
    if (districtFilter) districtFilter.addEventListener('change', () => { filterCommerces(); filterProducts(); });
}

// bind sort and page size UI
const sortSelect = document.getElementById('sortSelect');
const pageSizeSelect = document.getElementById('pageSizeSelect');
if (sortSelect) sortSelect.addEventListener('change', () => { currentSort = sortSelect.value; currentPage = 1; filterCommerces(); filterProducts(); });
if (pageSizeSelect) pageSizeSelect.addEventListener('change', () => { pageSize = parseInt(pageSizeSelect.value, 10) || 9; currentPage = 1; filterProducts(); });

// geolocation helpers
const locateBtn = document.getElementById('locateBtn');
function haversine(lat1, lon1, lat2, lon2) {
    const toRad = v => v * Math.PI / 180;
    const R = 6371; // km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

function saveUserLocation(loc) {
    userLocation = loc;
    try { localStorage.setItem('findshop_user_location', JSON.stringify(loc)); } catch(e){}
}

function loadUserLocation() {
    try {
        const raw = localStorage.getItem('findshop_user_location');
        if (raw) userLocation = JSON.parse(raw);
    } catch(e){}
}

async function requestLocation() {
    if (!navigator.geolocation) {
        showAlert('Géolocalisation non disponible', 'error');
        return;
    }
    showAlert('Demande de position en cours...', 'info');
    navigator.geolocation.getCurrentPosition((pos) => {
        const loc = { lat: pos.coords.latitude, lon: pos.coords.longitude };
        saveUserLocation(loc);
        showAlert('Position récupérée', 'success');
        filterCommerces(); filterProducts();
    }, (err) => {
        console.error(err);
        showAlert('Permission refusée ou erreur de géolocalisation', 'error');
    });
}

if (locateBtn) locateBtn.addEventListener('click', requestLocation);
loadUserLocation();

// augment renderProducts to support proximity sort
const originalRenderProducts = renderProducts;

bindSearchUI();

// Filtre et met à jour l'affichage des produits en fonction des contrôles de recherche
function filterProducts() {
    if (!products || products.length === 0) return renderProducts([]);
    const qEl = document.getElementById('searchInput');
    const catEl = document.getElementById('categoryFilter');
    const distEl = document.getElementById('districtFilter');
    const q = qEl ? qEl.value.trim().toLowerCase() : '';
    const cat = catEl ? catEl.value : '';
    const dist = distEl ? distEl.value : '';

    const res = products.filter(p => {
        const matchQ = q === '' || (p.nom && p.nom.toLowerCase().includes(q)) || (p.commerceNom && p.commerceNom.toLowerCase().includes(q));
        const matchCat = cat === '' || p.categorie === cat;
        const matchDist = dist === '' || p.quartier === dist;
        return matchQ && matchCat && matchDist;
    });

    renderProducts(res);
}

// Après le chargement des commerces, construire aussi le tableau `products` puis afficher
const originalLoadCommerces = loadCommerces;
loadCommerces = async function() {
    await originalLoadCommerces();
    // expose commerces globally for other modules (map, debug)
    window.commerces = commerces;
    const fromCommerces = buildProductsFromCommerces(commerces);
    const stored = loadStoredProducts();
    // stored products are expected to have keys similar to {id, nom, description, prix, categorie}
    // Normalize stored products into catalogue format
    const normalizedStored = stored.map(p => {
        // try to find commerce lat/lon from commerces array
        const comm = commerces.find(c => c.id === p.commerceId) || {};
        return {
            nom: p.nom,
            prix: p.prix,
            commerceId: p.commerceId || null,
            commerceNom: p.commerceNom || 'Commerçant',
            categorie: p.categorie || '',
            quartier: p.quartier || p.commerceQuartier || '',
            image: p.image || p.commerceImage || '',
            commerceQuartier: p.commerceQuartier || '',
            commerceImage: p.commerceImage || '',
            lat: p.lat || comm.lat || comm.latitude || null,
            lon: p.lon || comm.lon || comm.longitude || null
        };
    });

    products = [...normalizedStored, ...fromCommerces];
    renderProducts(products);
    renderWeeklyTrivia(commerces, products);
}

loadCommerces();

// Réagir quand un produit est ajouté via l'espace commerçant
window.addEventListener('product:added', (e) => {
    const p = e.detail;
    // Normalize and prepend to products
    const comm = commerces.find(c => c.id === p.commerceId) || {};
    const normalized = {
        nom: p.nom,
        prix: p.prix,
        commerceId: p.commerceId || null,
        commerceNom: p.commerceNom || 'Commerçant',
        categorie: p.categorie || '',
        quartier: p.quartier || p.commerceQuartier || '',
        image: p.image || p.commerceImage || '',
        commerceQuartier: p.commerceQuartier || '',
        commerceImage: p.commerceImage || '',
        lat: p.lat || comm.lat || comm.latitude || null,
        lon: p.lon || comm.lon || comm.longitude || null
    };
    products.unshift(normalized);
    renderProducts(products);
});