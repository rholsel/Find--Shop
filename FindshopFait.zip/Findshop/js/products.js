const productForm =
    document.getElementById(
        "productForm"
    );

const commerceSelect =
    document.getElementById(
        "commerceSelect"
    );

const imageInput = document.getElementById('image');
const imagePreview = document.getElementById('imagePreview');
const imageError = document.getElementById('imageError');

const DEFAULT_PRODUCT_IMAGE = 'assets/images/default-product.svg';
const IMAGE_MAX_SIZE = 2 * 1024 * 1024; // 2MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

if (typeof requireAuth === 'function') requireAuth('login.html');

let commercesForForm = [];

async function loadCommerceOptions() {
    if (!commerceSelect) return;

    try {
        const response = await fetch('./data/commerces.json');
        const commerces = await response.json();
        commercesForForm = commerces;

        commerceSelect.innerHTML = `
            <option value="">Sélectionner un commerce</option>
            ${commerces.map(c => `
                <option value="${c.id}">
                    ${c.nom} — ${c.quartier}
                </option>
            `).join('')}
        `;
    } catch (error) {
        console.error('Impossible de charger les commerces', error);
        commerceSelect.innerHTML = `
            <option value="">Erreur de chargement</option>
        `;
    }
}

function validateImageFile(file) {
    if (!file) return 'Fichier invalide';
    if (!ALLOWED_TYPES.includes(file.type)) return 'Format non pris en charge (jpg/png/webp requis)';
    if (file.size > IMAGE_MAX_SIZE) return 'Image trop volumineuse (max 2MB)';
    return null;
}

function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Erreur lecture fichier'));
        reader.readAsDataURL(file);
    });
}

if (imageInput) {
    imageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) {
            if (imagePreview) imagePreview.src = DEFAULT_PRODUCT_IMAGE;
            if (imageError) imageError.textContent = '';
            return;
        }

        const err = validateImageFile(file);
        if (err) {
            if (imageError) imageError.textContent = err;
            e.target.value = '';
            if (imagePreview) imagePreview.src = DEFAULT_PRODUCT_IMAGE;
            return;
        }

        if (imageError) imageError.textContent = '';
        const reader = new FileReader();
        reader.onload = () => {
            if (imagePreview) imagePreview.src = reader.result;
        };
        reader.readAsDataURL(file);
    });
}

if(productForm){

    productForm.addEventListener(
        "submit",
        async function(e){

            e.preventDefault();

            const submitBtn = productForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                const prevText = submitBtn.innerText;
                submitBtn.innerText = 'Ajout...';
            }

            const nom =
                document
                .getElementById("nom")
                .value
                .trim();

            const description =
                document
                .getElementById("description")
                .value
                .trim();

            const prix =
                parseFloat(
                    document
                    .getElementById("prix")
                    .value
                );

            const categorie =
                document
                .getElementById("categorie")
                .value;

            const commerceId =
                commerceSelect
                ? parseInt(commerceSelect.value, 10)
                : null;

            if(
                nom === "" ||
                description === "" ||
                categorie === "" ||
                !commerceId
            ){

                showAlert(
                    "Veuillez remplir tous les champs et choisir un commerce",
                    "error"
                );

                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = 'Ajouter';
                }

                return;
            }

            if(prix <= 0){

                showAlert(
                    "Le prix doit être supérieur à 0",
                    "error"
                );

                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = 'Ajouter';
                }

                return;
            }

            // handle image file (optional)
            let imageData = DEFAULT_PRODUCT_IMAGE;
            const imageFile = document.getElementById('image')?.files?.[0];
            if (imageFile) {
                const imgErr = validateImageFile(imageFile);
                if (imgErr) {
                    showAlert(imgErr, 'error');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerText = 'Ajouter';
                    }
                    return;
                }

                try {
                    imageData = await fileToDataURL(imageFile);
                } catch (e) {
                    console.error('Erreur lecture image', e);
                    showAlert('Impossible de lire l\'image', 'error');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerText = 'Ajouter';
                    }
                    return;
                }
            }

            const produits = JSON.parse(localStorage.getItem("findshop_products")) || [];
            const selectedCommerce = commercesForForm.find(c => c.id === commerceId) || {};

            const authUser = typeof getAuthenticatedUser === 'function' ? getAuthenticatedUser() : null;
            const newProduct = {
                id: Date.now(),
                nom,
                description,
                prix,
                categorie,
                commerceId,
                commerceNom: selectedCommerce.nom || '',
                commerceQuartier: selectedCommerce.quartier || '',
                commerceImage: selectedCommerce.image || '',
                image: imageData,
                createdBy: authUser ? authUser.email : null,
                creatorName: authUser ? authUser.shopName : ''
            };

            // Simulate small async save to show loading state
            try {
                // pretend to call an API
                await new Promise(resolve => setTimeout(resolve, 400));

                produits.push(newProduct);
                localStorage.setItem("findshop_products", JSON.stringify(produits));

                // Dispatch a global event so other parts of the app can react
                window.dispatchEvent(new CustomEvent('product:added', { detail: newProduct }));

                showAlert("Produit ajouté avec succès", "success");

                productForm.reset();
                if (imagePreview) imagePreview.src = DEFAULT_PRODUCT_IMAGE;
                if (imageError) imageError.textContent = '';
            } catch (err) {
                console.error(err);
                showAlert("Erreur lors de l'ajout du produit", "error");
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = 'Ajouter';
                }
            }
        }
    );
}

loadCommerceOptions();