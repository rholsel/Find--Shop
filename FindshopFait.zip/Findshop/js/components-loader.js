/**
 * Charge les composants HTML (header et footer) dynamiquement
 * Utilise fetch pour charger les fichiers HTML et les injecter dans le DOM
 */

async function loadComponent(componentName, targetSelector) {
    try {
        const response = await fetch(`components/${componentName}.html`);
        if (!response.ok) throw new Error(`Erreur lors du chargement de ${componentName}`);
        const html = await response.text();
        const target = document.querySelector(targetSelector);
        if (target) {
            target.innerHTML = html;
        } else {
            console.warn(`Cible '${targetSelector}' non trouvée`);
        }
    } catch (error) {
        console.error(`Erreur lors du chargement du composant ${componentName}:`, error);
    }
}

/**
 * Détermine le header à charger selon le rôle de l'utilisateur
 * - Non connecté → header.html (par défaut)
 * - Commerçant → header-merchant.html
 * - Visiteur/Client → header-visitor.html
 */
function getHeaderComponentName() {
    try {
        // Récupère l'utilisateur depuis le localStorage
        const authRaw = localStorage.getItem('findshop_auth');
        if (!authRaw) {
            console.log('[Header] Pas d\'utilisateur connecté, chargement header par défaut');
            return 'header';
        }
        
        const authUser = JSON.parse(authRaw);
        if (authUser.role === 'merchant') {
            console.log('[Header] Utilisateur commerçant détecté, chargement header-merchant');
            return 'header-merchant';
        }
        
        console.log('[Header] Utilisateur visiteur/client détecté, chargement header-visitor');
        return 'header-visitor';
    } catch (error) {
        console.error('[Header] Erreur lors de la détection du rôle:', error);
        return 'header';
    }
}

// Charger les composants immédiatement si le DOM est déjà chargé, sinon attendre
async function initializeComponents() {
    console.log('[Components] Initialisation des composants...');
    
    // Charger le header et le footer en parallèle
    await Promise.all([
        loadComponent(getHeaderComponentName(), 'header'),
        loadComponent('footer', 'footer')
    ]);
    
    console.log('[Components] Composants chargés, initialisation des écouteurs...');
    
    // Réappliquer les écouteurs d'événements si nécessaire
    initializeAuthPanel();
    if (typeof window.updateAuthUI === 'function') {
        window.updateAuthUI();
    }
    if (typeof window.checkLogoutButtons === 'function') {
        window.checkLogoutButtons();
    }
    
    // Déclencher un événement personnalisé pour signaler que les composants sont chargés
    window.dispatchEvent(new Event('componentsLoaded'));
}

/**
 * Réinitialise le panneau d'authentification après le chargement du header
 * (pour que les événements de déconnexion fonctionnent)
 */
function initializeAuthPanel() {
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            if (window.logout) {
                window.logout();
            }
        });
    }
}

// Charger les composants dès que possible
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeComponents);
} else {
    initializeComponents();
}