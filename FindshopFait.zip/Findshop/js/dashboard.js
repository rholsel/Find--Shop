const commerceSelect = document.getElementById('dashboardCommerceSelect');
const productsContainer = document.getElementById('dashboardProducts');
const statCount = document.getElementById('statCount');
const statFavorites = document.getElementById('statFavorites');
const currentUser = typeof getAuthenticatedUser === 'function' ? getAuthenticatedUser() : null;

// === VÉRIFICATION DE SÉCURITÉ ===
// Seuls les commerçants peuvent accéder au dashboard
if (typeof requireRole === 'function') {
    requireRole('merchant', 'index.html');
}

const PRODUCTS_KEY = 'findshop_products';
const STATS_KEY = 'findshop_stats';

async function loadCommercesForDashboard() {
    try {
        const resp = await fetch('./data/commerces.json');
        const data = await resp.json();
        // merge stored commerces images if present
        try {
            const storedRaw = localStorage.getItem('findshop_commerces');
            const stored = storedRaw ? JSON.parse(storedRaw) : [];
            if (Array.isArray(stored) && stored.length) {
                data.forEach((c, i) => {
                    const s = stored.find(x => x.id === c.id);
                    if (s) Object.assign(c, s);
                });
            }
        } catch(e) { console.error(e); }
        commerceSelect.innerHTML = `<option value="">Choisir un commerce</option>` + data.map(c => `<option value="${c.id}">${c.nom} — ${c.quartier}</option>`).join('');
    } catch (e) {
        console.error('Impossible de charger commerces', e);
        commerceSelect.innerHTML = `<option value="">Erreur</option>`;
    }
}

function loadStoredProducts() {
    try {
        const raw = localStorage.getItem(PRODUCTS_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (e) { console.error(e); return []; }
}

function loadStats() {
    try { const raw = localStorage.getItem(STATS_KEY); return raw ? JSON.parse(raw) : {}; } catch(e){console.error(e); return {};}
}

function saveStoredProducts(list) {
    try { localStorage.setItem(PRODUCTS_KEY, JSON.stringify(list)); } catch(e){console.error(e);} 
}

function saveStats(obj) { try { localStorage.setItem(STATS_KEY, JSON.stringify(obj)); } catch(e){console.error(e);} }

function buildProductsForCommerce(commerceId) {
    // from data/commerces.json (original products)
    // and stored products (editable)
    const stored = loadStoredProducts();
    const originals = [];
    try {
        // fetch synchronous cached data? re-fetch
    } catch(e){}
    // We'll re-fetch data/commerces.json to get originals
}

async function renderProductsForCommerce(commerceId) {
    productsContainer.innerHTML = '';
    if (!commerceId) return;

    // load originals
    let originals = [];
    try {
        const resp = await fetch('./data/commerces.json');
        const data = await resp.json();
        const commerce = data.find(c => c.id === parseInt(commerceId, 10));
        if (commerce && Array.isArray(commerce.produits)) {
            originals = commerce.produits.map((p, idx) => ({
                _original: true,
                _idx: idx,
                nom: p.nom,
                prix: p.prix,
                image: p.image || commerce.image || '',
                description: p.description || ''
            }));
        }
    } catch(e){ console.error('Erreur chargement originaux', e); }

    const stored = loadStoredProducts().filter(p => p.commerceId === Number(commerceId) && (!currentUser || p.createdBy === currentUser.email));

    const stats = loadStats();
    const totalProducts = originals.length + stored.length;
    const totalFavorites = stored.reduce((acc,p) => acc + ((stats[p.id] && stats[p.id].favorites) || 0), 0);

    statCount.textContent = totalProducts;
    statFavorites.textContent = totalFavorites;

    // render originals (non-editable)
    originals.forEach(p => {
        const card = document.createElement('div');
        card.className = 'bg-gray-50 border rounded p-4';
        card.innerHTML = `
            <div class="flex gap-4">
                <img src="${p.image || 'assets/images/default-product.svg'}" class="w-24 h-20 object-cover rounded" />
                <div>
                    <div class="font-semibold">${p.nom} <small class="text-sm text-gray-500">(origine)</small></div>
                    <div class="text-indigo-600 font-bold">${Number(p.prix).toFixed(2)} $</div>
                    <p class="text-gray-600 mt-2">${p.description || ''}</p>
                </div>
            </div>
        `;
        productsContainer.appendChild(card);
    });

    // render stored (editable)
    stored.forEach(p => {
        const card = document.createElement('div');
        card.className = 'bg-white border rounded p-4';
        card.innerHTML = `
            <div class="flex justify-between items-start">
                <div class="flex gap-4">
                    <img src="${p.image || 'assets/images/default-product.svg'}" class="w-24 h-20 object-cover rounded" />
                    <div>
                        <div class="font-semibold">${p.nom}</div>
                        <div class="text-indigo-600 font-bold">${Number(p.prix).toFixed(2)} $</div>
                        <p class="text-gray-600 mt-2 text-sm">${p.description || ''}</p>
                    </div>
                </div>
                <div class="flex flex-col gap-2">
                    <button class="edit-btn bg-yellow-400 px-3 py-1 rounded">Modifier</button>
                    <button class="delete-btn bg-red-500 text-white px-3 py-1 rounded">Supprimer</button>
                    <button class="fav-btn bg-blue-600 text-white px-3 py-1 rounded">Favori (+)</button>
                </div>
            </div>
        `;

        // attach actions
        const editBtn = card.querySelector('.edit-btn');
        const delBtn = card.querySelector('.delete-btn');
        const favBtn = card.querySelector('.fav-btn');

        editBtn.addEventListener('click', () => openEditForm(card, p));
        delBtn.addEventListener('click', () => deleteStoredProduct(p.id));
        favBtn.addEventListener('click', () => incrementFavorite(p.id));

        productsContainer.appendChild(card);
    });
}

function openEditForm(cardEl, product) {
    // replace card content with form
    cardEl.innerHTML = `
        <form class="grid gap-2">
            <div class="flex gap-2">
                <input name="nom" value="${escapeHtml(product.nom)}" class="border p-2 rounded w-full" />
                <input name="prix" value="${product.prix}" type="number" class="border p-2 rounded w-32" />
            </div>
            <textarea name="description" class="border p-2 rounded">${escapeHtml(product.description || '')}</textarea>
            <div class="flex gap-2">
                <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded">Enregistrer</button>
                <button type="button" class="cancel-btn bg-gray-300 px-3 py-1 rounded">Annuler</button>
            </div>
        </form>
    `;

    const form = cardEl.querySelector('form');
    const cancel = cardEl.querySelector('.cancel-btn');

    cancel.addEventListener('click', () => renderProductsForCommerce(product.commerceId));

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const nom = form.elements['nom'].value.trim();
        const prix = parseFloat(form.elements['prix'].value);
        const description = form.elements['description'].value.trim();
        if (!nom || isNaN(prix) || prix <= 0) { alert('Nom et prix valides requis'); return; }
        // update stored product
        const all = loadStoredProducts();
        const idx = all.findIndex(x => x.id === product.id);
        if (idx >= 0) {
            all[idx].nom = nom;
            all[idx].prix = prix;
            all[idx].description = description;
            saveStoredProducts(all);
            alert('Produit mis à jour');
            // notify app
            window.dispatchEvent(new CustomEvent('product:updated', { detail: all[idx] }));
            renderProductsForCommerce(product.commerceId);
        }
    });
}

function deleteStoredProduct(productId) {
    if (!confirm('Supprimer ce produit ?')) return;
    const all = loadStoredProducts();
    const remaining = all.filter(p => p.id !== productId);
    saveStoredProducts(remaining);
    alert('Produit supprimé');
    // refresh
    const selected = commerceSelect.value;
    renderProductsForCommerce(selected);
}

function incrementFavorite(productId) {
    const stats = loadStats();
    if (!stats[productId]) stats[productId] = { views: 0, favorites: 0 };
    stats[productId].favorites = (stats[productId].favorites || 0) + 1;
    saveStats(stats);
    // refresh stats display
    const selected = commerceSelect.value;
    renderProductsForCommerce(selected);
}

function escapeHtml(unsafe) {
    return (unsafe+'').replace(/[&<>"']/g, function(m) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]); });
}

// init
loadCommercesForDashboard();
commerceSelect.addEventListener('change', (e) => {
    const id = e.target.value;
    renderProductsForCommerce(id);
});

// react to product added/updated events to refresh when dashboard open
window.addEventListener('product:added', (e) => {
    const selected = commerceSelect.value;
    if (selected && Number(e.detail.commerceId) === Number(selected)) renderProductsForCommerce(selected);
});
window.addEventListener('product:updated', (e) => {
    const selected = commerceSelect.value;
    if (selected && Number(e.detail.commerceId) === Number(selected)) renderProductsForCommerce(selected);
});
