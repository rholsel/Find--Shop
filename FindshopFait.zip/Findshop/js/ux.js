const FAVORITES_KEY = 'findshop_favorites';
const REVIEWS_KEY = 'findshop_reviews';

function loadFavorites() {
    try {
        const raw = localStorage.getItem(FAVORITES_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error('Erreur lecture favoris', e);
        return [];
    }
}

function saveFavorites(list) {
    try {
        localStorage.setItem(FAVORITES_KEY, JSON.stringify(list));
    } catch (e) {
        console.error('Erreur sauvegarde favoris', e);
    }
}

function getProductUniqueKey(item) {
    if (!item) return '';
    if (item.id) return `product-${item.id}`;
    if (item.commerceId && item.nom) return `product-${item.commerceId}-${item.nom}`;
    if (item.nom) return `product-unknown-${item.nom}`;
    return `product-unknown`;
}

function isFavorite(product) {
    const key = getProductUniqueKey(product);
    const favorites = loadFavorites();
    return favorites.includes(key);
}

function toggleFavorite(product) {
    // If authentication helper is available, require auth for toggling favorites
    if (typeof isAuthenticated === 'function' && !isAuthenticated()) {
        if (typeof requireAuth === 'function') {
            requireAuth('login.html');
        } else {
            window.location.href = 'login.html';
        }
        return false;
    }

    const key = getProductUniqueKey(product);
    const favorites = loadFavorites();
    const index = favorites.indexOf(key);
    if (index >= 0) {
        favorites.splice(index, 1);
        saveFavorites(favorites);
        return false;
    }
    favorites.push(key);
    saveFavorites(favorites);
    return true;
}

function loadReviews() {
    try {
        const raw = localStorage.getItem(REVIEWS_KEY);
        return raw ? JSON.parse(raw) : {};
    } catch (e) {
        console.error('Erreur lecture avis', e);
        return {};
    }
}

function saveReviews(data) {
    try {
        localStorage.setItem(REVIEWS_KEY, JSON.stringify(data));
    } catch (e) {
        console.error('Erreur sauvegarde avis', e);
    }
}

function getReviewsForCommerce(commerceId) {
    const reviews = loadReviews();
    return Array.isArray(reviews[commerceId]) ? reviews[commerceId] : [];
}

function addReviewToCommerce(commerceId, review) {
    const reviews = loadReviews();
    if (!Array.isArray(reviews[commerceId])) {
        reviews[commerceId] = [];
    }
    reviews[commerceId].push(review);
    saveReviews(reviews);
}

function getCommerceAverageRating(commerceId) {
    const reviews = getReviewsForCommerce(commerceId);
    if (!reviews.length) return null;
    const total = reviews.reduce((sum, review) => sum + Number(review.rating || 0), 0);
    return total / reviews.length;
}

function renderStars(value, max = 5) {
    if (typeof value !== 'number' || Number.isNaN(value)) value = 0;
    const rounded = Math.round(value * 2) / 2;
    let stars = '';
    for (let i = 1; i <= max; i++) {
        if (rounded >= i) {
            stars += '★';
        } else if (rounded + 0.5 === i) {
            stars += '☆';
        } else {
            stars += '☆';
        }
    }
    return stars;
}

window.loadFavorites = loadFavorites;
window.saveFavorites = saveFavorites;
window.getProductUniqueKey = getProductUniqueKey;
window.isFavorite = isFavorite;
window.toggleFavorite = toggleFavorite;
window.loadReviews = loadReviews;
window.saveReviews = saveReviews;
window.getReviewsForCommerce = getReviewsForCommerce;
window.addReviewToCommerce = addReviewToCommerce;
window.getCommerceAverageRating = getCommerceAverageRating;
function isFavoriteKey(key) {
    const favorites = loadFavorites();
    return favorites.includes(key);
}

function toggleFavoriteKey(key) {
    // Require authentication before toggling by key
    if (typeof isAuthenticated === 'function' && !isAuthenticated()) {
        if (typeof requireAuth === 'function') {
            requireAuth('login.html');
        } else {
            window.location.href = 'login.html';
        }
        return false;
    }

    const favorites = loadFavorites();
    const index = favorites.indexOf(key);
    if (index >= 0) {
        favorites.splice(index, 1);
        saveFavorites(favorites);
        return false;
    }
    favorites.push(key);
    saveFavorites(favorites);
    return true;
}

window.isFavoriteKey = isFavoriteKey;
window.toggleFavoriteKey = toggleFavoriteKey;

window.renderStars = renderStars;
