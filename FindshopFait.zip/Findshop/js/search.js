function filterCommerces() {

    const search =
        document
        .getElementById("searchInput")
        .value
        .toLowerCase();

    const category =
        document
        .getElementById("categoryFilter")
        .value;

    const district =
        document
        .getElementById("districtFilter")
        .value;

    const result = commerces.filter(item => {

        const matchSearch =
            item.nom
            .toLowerCase()
            .includes(search);

        const matchCategory =
            category === "" ||
            item.categorie === category;

        const matchDistrict =
            district === "" ||
            item.quartier === district;

        return (
            matchSearch &&
            matchCategory &&
            matchDistrict
        );
    });

    // if proximity sort requested, sort by distance when we have user location and commerces have coords
    try {
        if (typeof currentSort !== 'undefined' && currentSort === 'proximity' && typeof userLocation !== 'undefined' && userLocation) {
            result.forEach(r => {
                const lat = r.lat || r.latitude || null;
                const lon = r.lon || r.longitude || null;
                if (lat != null && lon != null) r._distance = haversine(userLocation.lat, userLocation.lon, Number(lat), Number(lon));
                else r._distance = Infinity;
            });
            result.sort((a,b) => (a._distance||Infinity) - (b._distance||Infinity));
        }
    } catch(e) { console.error(e); }

    renderCommerces(result);
}