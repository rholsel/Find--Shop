const logoInput = document.getElementById('logoInput');
const coverInput = document.getElementById('coverInput');
const logoPreview = document.getElementById('logoPreview');
const coverPreview = document.getElementById('coverPreview');

if (typeof requireAuth === 'function') requireAuth('login.html');
const commerceImageError = document.getElementById('commerceImageError');
const updateBtn = document.getElementById('updateCommerceImagesBtn');

const STORAGE_KEY_COMM = 'findshop_commerces';
const DEFAULT_IMAGE = 'assets/images/default-product.svg';
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const IMAGE_MAX_SIZE = 2 * 1024 * 1024; // 2MB

function validateImageFile(file) {
    if (!file) return 'Fichier invalide';
    if (!ALLOWED_TYPES.includes(file.type)) return 'Format non pris en charge (jpg/png/webp requis)';
    if (file.size > IMAGE_MAX_SIZE) return 'Image trop volumineuse (max 2MB)';
    return null;
}

function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Erreur lecture fichier'));
        reader.readAsDataURL(file);
    });
}

async function loadStoredCommercesMap() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY_COMM);
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error('Erreur lecture commerces stockés', e);
        return [];
    }
}

async function saveStoredCommerces(data) {
    try {
        localStorage.setItem(STORAGE_KEY_COMM, JSON.stringify(data));
    } catch (e) {
        console.error('Erreur sauvegarde commerces', e);
    }
}

// When selected commerce changes, try to load existing stored images
const commerceSelectEl = document.getElementById('commerceSelect');
const latInput = document.getElementById('latInput');
const lonInput = document.getElementById('lonInput');
if (commerceSelectEl) {
    commerceSelectEl.addEventListener('change', async () => {
        const id = parseInt(commerceSelectEl.value, 10);
        if (Number.isNaN(id)) return;

        // try stored commerces first
        const stored = await loadStoredCommercesMap();
        const found = stored.find(c => c.id === id);
        if (found) {
            if (found.logo) logoPreview.src = found.logo;
            if (found.cover) coverPreview.src = found.cover;
            if (latInput) latInput.value = typeof found.lat !== 'undefined' ? String(found.lat) : '';
            if (lonInput) lonInput.value = typeof found.lon !== 'undefined' ? String(found.lon) : '';
            return;
        }

        // fallback to data/commerces.json
        try {
            const resp = await fetch('./data/commerces.json');
            const commerces = await resp.json();
            const commerce = commerces.find(c => c.id === id) || {};
            if (commerce.image) coverPreview.src = commerce.image;
            if (latInput) latInput.value = commerce.lat || '';
            if (lonInput) lonInput.value = commerce.lon || '';
            // no explicit logo in sample data, keep default
        } catch (e) {
            console.error('Impossible de charger commerces pour preview', e);
        }
    });
}

// preview handlers
if (logoInput) {
    logoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        const err = validateImageFile(file);
        if (err) {
            commerceImageError.textContent = err;
            logoInput.value = '';
            logoPreview.src = DEFAULT_IMAGE;
            return;
        }
        commerceImageError.textContent = '';
        const reader = new FileReader();
        reader.onload = () => logoPreview.src = reader.result;
        reader.readAsDataURL(file);
    });
}

if (coverInput) {
    coverInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        const err = validateImageFile(file);
        if (err) {
            commerceImageError.textContent = err;
            coverInput.value = '';
            coverPreview.src = DEFAULT_IMAGE;
            return;
        }
        commerceImageError.textContent = '';
        const reader = new FileReader();
        reader.onload = () => coverPreview.src = reader.result;
        reader.readAsDataURL(file);
    });
}

// update stored commerce images
if (updateBtn) {
    updateBtn.addEventListener('click', async () => {
        const commerceId = parseInt(commerceSelectEl.value, 10);
        if (!commerceId) {
            commerceImageError.textContent = 'Choisissez d\'abord un commerce';
            return;
        }

        const stored = await loadStoredCommercesMap();
        const existing = stored.find(c => c.id === commerceId) || { id: commerceId };

        // process files
        try {
            if (logoInput.files[0]) {
                const err = validateImageFile(logoInput.files[0]);
                if (err) throw new Error(err);
                existing.logo = await fileToDataURL(logoInput.files[0]);
            }
            if (coverInput.files[0]) {
                const err = validateImageFile(coverInput.files[0]);
                if (err) throw new Error(err);
                existing.cover = await fileToDataURL(coverInput.files[0]);
            }

            // lat / lon
            if (latInput && latInput.value.trim() !== '') {
                const v = parseFloat(latInput.value);
                if (Number.isNaN(v)) throw new Error('Latitude invalide');
                existing.lat = v;
            }
            if (lonInput && lonInput.value.trim() !== '') {
                const v = parseFloat(lonInput.value);
                if (Number.isNaN(v)) throw new Error('Longitude invalide');
                existing.lon = v;
            }

            // replace or add
            const others = stored.filter(c => c.id !== commerceId);
            others.push(existing);
            await saveStoredCommerces(others);

            commerceImageError.textContent = '';
            alert('Images du commerce mises à jour');

            // clear file inputs
            logoInput.value = '';
            coverInput.value = '';
        } catch (e) {
            commerceImageError.textContent = e.message || 'Erreur lors de la mise à jour';
            console.error(e);
        }
    });
}
