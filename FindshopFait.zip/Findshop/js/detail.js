const container =
    document.getElementById(
        "commerceDetails"
    );

function loadStoredProducts() {
    try {
        const raw = localStorage.getItem('findshop_products');
        return raw ? JSON.parse(raw) : [];
    } catch (error) {
        console.error('Erreur de lecture des produits stockés', error);
        return [];
    }
}

async function loadCommerce() {
    const params = new URLSearchParams(window.location.search);
    const id = parseInt(params.get("id"), 10);

    if (Number.isNaN(id)) {
        container.innerHTML = `
            <div class="text-red-500">
                Identifiant de commerce invalide.
            </div>
        `;
        return;
    }

    try {
        const response = await fetch("./data/commerces.json");
        let commerces = await response.json();

        // overlay with stored commerces images (logo/cover)
        try {
            const rawStored = localStorage.getItem('findshop_commerces');
            const stored = rawStored ? JSON.parse(rawStored) : [];
            if (Array.isArray(stored) && stored.length) {
                commerces = commerces.map(c => {
                    const s = stored.find(x => x.id === c.id);
                    return s ? { ...c, ...s } : c;
                });
            }
        } catch (e) {
            console.error('Erreur lecture commerces stockés', e);
        }

        const commerce = commerces.find(c => c.id === id);

        if (!commerce) {
            container.innerHTML = `
                <div class="text-red-500">
                    Commerce introuvable.
                </div>
            `;
            return;
        }

        const storedProducts = loadStoredProducts();
        const linkedProducts = storedProducts.filter(p => p.commerceId === id);
        displayCommerce(commerce, linkedProducts);

    } catch (error) {
        console.error(error);
        container.innerHTML = `
            <div class="text-red-500">
                Erreur de chargement.
            </div>
        `;
    }
}

function displayCommerce(commerce, storedProducts) {
    const produitsHTML = [
        ...(Array.isArray(commerce.produits) ? commerce.produits : []),
        ...storedProducts
    ]
    .map(produit => {
        const produitData = produit.id ? produit : { ...produit, commerceId: commerce.id };
        const produitKey = getProductUniqueKey(produitData);
        const produitFavorite = isFavorite(produitData);
        return `
        <div class="border rounded p-4 mb-3">
            <div class="flex items-start justify-between gap-4">
                <div class="flex gap-4 items-start">
                    <img
                        src="${produit.image || 'https://picsum.photos/seed/product/300/200'}"
                        alt="${produit.nom}"
                        class="w-24 h-24 object-cover rounded"
                    >
                    <div>
                        <h4 class="font-bold text-lg">${produit.nom}</h4>
                        <p class="text-green-600 font-semibold">${produit.prix} $</p>
                        <p class="text-sm text-gray-600 mt-1">${produit.description || ''}</p>
                    </div>
                </div>
                <button type="button" class="favorite-btn text-2xl ${produitFavorite ? 'text-red-500' : 'text-gray-400'}" data-product-key="${produitKey}">
                    ${produitFavorite ? '♥' : '♡'}
                </button>
            </div>
        </div>
    `;
    })
    .join("");

    container.innerHTML = `
        <div class="grid lg:grid-cols-[2fr_1fr] gap-8">
            <div>
                <img
                    src="${commerce.image || 'https://picsum.photos/seed/commerce/900/500'}"
                    alt="${commerce.nom}"
                    class="w-full h-80 object-cover rounded-lg mb-6"
                >

                <h1 class="text-4xl font-bold mb-3">${commerce.nom}</h1>
                <p class="text-gray-600 mb-6">${commerce.description}</p>

                <div class="grid gap-3 sm:grid-cols-2">
                    <div class="bg-gray-50 p-4 rounded">
                        <p class="text-sm text-gray-500">Quartier</p>
                        <p class="font-semibold">${commerce.quartier}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded">
                        <p class="text-sm text-gray-500">Adresse</p>
                        <p class="font-semibold">${commerce.adresse}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded">
                        <p class="text-sm text-gray-500">Téléphone</p>
                        <p class="font-semibold">${commerce.telephone}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded">
                        <p class="text-sm text-gray-500">Horaires</p>
                        <p class="font-semibold">${commerce.horaires}</p>
                    </div>
                </div>
            </div>

            <aside class="bg-white border rounded-lg p-6 shadow-sm">
                <h2 class="text-2xl font-bold mb-4">Infos rapides</h2>
                <p class="mb-2"><strong>Catégorie :</strong> ${commerce.categorie}</p>
                <p class="mb-2"><strong>Quartier :</strong> ${commerce.quartier}</p>
                <p class="mb-2"><strong>Adresse :</strong> ${commerce.adresse}</p>
                <p class="mb-2"><strong>Téléphone :</strong> ${commerce.telephone}</p>
                <p class="mb-2"><strong>Horaires :</strong> ${commerce.horaires}</p>
            </aside>
        </div>

        <section class="mt-10">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold mb-4">Notes & avis</h2>
                    <div id="commerceRatingSummary" class="text-yellow-500 text-lg mb-2"></div>
                </div>
            </div>
            <form id="reviewForm" class="grid gap-3 bg-gray-50 p-4 rounded-lg mb-6">
                <div class="grid md:grid-cols-2 gap-4">
                    <label class="block">
                        Note
                        <select id="ratingSelect" class="w-full border p-2 rounded mt-1">
                            <option value="">Choisir une note</option>
                            <option value="5">5 étoiles</option>
                            <option value="4">4 étoiles</option>
                            <option value="3">3 étoiles</option>
                            <option value="2">2 étoiles</option>
                            <option value="1">1 étoile</option>
                        </select>
                    </label>
                    <label class="block">
                        Commentaire
                        <textarea id="commentInput" rows="3" class="w-full border p-2 rounded mt-1" placeholder="Votre avis..."></textarea>
                    </label>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Publier l'avis</button>
            </form>
            <div id="reviewsContainer" class="space-y-4"></div>
        </section>
        <section class="mt-10">
            <h2 class="text-2xl font-bold mb-4">Produits</h2>
            ${produitsHTML}
        </section>
    `;

    renderCommerceReviews(commerce.id);
    attachReviewForm(commerce.id);
    attachProductFavoriteButtons();
}


function renderCommerceReviews(commerceId) {
    const summary = document.getElementById('commerceRatingSummary');
    const list = document.getElementById('reviewsContainer');
    const reviews = getReviewsForCommerce(commerceId);
    const average = getCommerceAverageRating(commerceId);

    if (summary) {
        summary.innerHTML = average
            ? `${renderStars(average)} <span class="text-gray-600 font-medium">${average.toFixed(1)} (${reviews.length} avis)</span>`
            : "Aucune note pour l'instant";
    }

    if (list) {
        list.innerHTML = reviews.length > 0
            ? reviews.map(review => `
                <div class="border rounded p-4 bg-gray-50">
                    <div class="flex items-center gap-2 text-yellow-500">${renderStars(review.rating)}</div>
                    <p class="text-sm text-gray-700 mt-2">${review.comment || '<em>Pas de commentaire</em>'}</p>
                    <p class="text-xs text-gray-500 mt-2">${new Date(review.createdAt).toLocaleDateString('fr-FR')}</p>
                </div>
            `).join('')
            : '<div class="text-gray-500">Aucun avis publié pour le moment.</div>';
    }
}

function attachReviewForm(commerceId) {
    const reviewForm = document.getElementById('reviewForm');
    if (!reviewForm) return;
    reviewForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const rating = parseInt(document.getElementById('ratingSelect').value, 10);
        const comment = document.getElementById('commentInput').value.trim();
        if (!rating || rating < 1 || rating > 5) {
            alert('Merci de choisir une note entre 1 et 5.');
            return;
        }
        addReviewToCommerce(commerceId, {
            rating,
            comment,
            createdAt: new Date().toISOString()
        });
        document.getElementById('ratingSelect').value = '';
        document.getElementById('commentInput').value = '';
        renderCommerceReviews(commerceId);
        alert('Merci pour votre avis !');
    });
}

function attachProductFavoriteButtons() {
    const buttons = container.querySelectorAll('.favorite-btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const key = btn.dataset.productKey;
            if (!key) return;
            const toggled = toggleFavoriteKey(key);
            btn.textContent = toggled ? '♥' : '♡';
            btn.classList.toggle('text-red-500', toggled);
            btn.classList.toggle('text-gray-400', !toggled);
        });
    });
}
loadCommerce();