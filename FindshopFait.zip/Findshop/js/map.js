const mapContainer = document.getElementById('map');
let map;
let markerLayer;
let userMarker;

function createMap() {
    if (!mapContainer) return;
    map = L.map('map');
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 18,
    }).addTo(map);
    markerLayer = L.layerGroup().addTo(map);
}

function formatPopup(commerce) {
    const distanceText = window.userLocation && commerce.lat != null && commerce.lon != null
        ? `\n<br>Distance : ${haversine(window.userLocation.lat, window.userLocation.lon, Number(commerce.lat), Number(commerce.lon)).toFixed(1)} km`
        : '';
    return `
        <div style="min-width:180px;">
            <strong>${commerce.nom}</strong><br>
            ${commerce.categorie || ''}<br>
            ${commerce.quartier || ''}
            ${distanceText}<br>
            <a href="detail-commerce.html?id=${commerce.id}" style="color:#1d4ed8; text-decoration:none;">Voir le commerce</a>
        </div>
    `;
}

function updateMapMarkers(commercesToShow) {
    if (!mapContainer) return;
    if (!map) createMap();
    markerLayer.clearLayers();

    const bounds = [];

    commercesToShow.forEach(commerce => {
        const lat = commerce.lat || commerce.latitude;
        const lon = commerce.lon || commerce.longitude;
        if (typeof lat !== 'undefined' && typeof lon !== 'undefined' && lat !== null && lon !== null) {
            const marker = L.marker([Number(lat), Number(lon)]);
            marker.bindPopup(formatPopup(commerce));
            marker.addTo(markerLayer);
            bounds.push([Number(lat), Number(lon)]);
        }
    });

    if (window.userLocation && map) {
        if (userMarker) {
            userMarker.setLatLng([window.userLocation.lat, window.userLocation.lon]);
        } else {
            userMarker = L.circleMarker([window.userLocation.lat, window.userLocation.lon], {
                radius: 8,
                color: '#10b981',
                fillColor: '#10b981',
                fillOpacity: 0.9,
            }).addTo(map).bindPopup('Vous êtes ici');
        }
        bounds.push([window.userLocation.lat, window.userLocation.lon]);
    }

    if (bounds.length > 0) {
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
        map.invalidateSize();
    } else if (map) {
        map.setView([0, 0], 2);
        map.invalidateSize();
    }
}

window.addEventListener('commerces:rendered', (event) => {
    if (!event.detail) return;
    updateMapMarkers(event.detail);
});

window.addEventListener('load', () => {
    if (window.commerces && window.commerces.length) {
        updateMapMarkers(window.commerces);
    }
});
