const STORAGE_KEY = "findshop_commerces";

function saveCommerces(commerces) {
    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(commerces)
    );
}

function getCommerces() {

    const data =
        localStorage.getItem(STORAGE_KEY);

    return data
        ? JSON.parse(data)
        : [];
}