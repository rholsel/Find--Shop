/**
 * === COMPTES DE TEST FINDSHOP ===
 * 
 * Ce fichier contient les comptes de test prédéfinis et une fonction
 * pour les initialiser dans le localStorage.
 * 
 * UTILISATION:
 * 1. Charger ce script dans index.html ou login.html
 * 2. Appeler initTestAccounts() au chargement de la page
 * 3. Utiliser les identifiants ci-dessous pour vous connecter
 */

const TEST_ACCOUNTS = {
    visitor: {
        email: 'visitor@test.com',
        password: 'test1234',
        role: 'visitor',
        shopName: null
    },
    merchant: {
        email: 'merchant@test.com',
        password: 'test1234',
        role: 'merchant',
        shopName: 'Ma Boutique Test'
    }
};

/**
 * Initialise les comptes de test dans le localStorage
 * Crée les comptes s'ils n'existent pas déjà
 */
async function initTestAccounts() {
    const USERS_KEY = 'findshop_users';
    const usersRaw = localStorage.getItem(USERS_KEY);
    let users = usersRaw ? JSON.parse(usersRaw) : [];
    
    console.log('[TestAccounts] Initialisation des comptes de test...');
    
    // Fonction pour hasher le mot de passe (doit correspondre à auth.js)
    async function hashPassword(password) {
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return hashHex;
    }
    
    // Créer les comptes de test
    for (const [key, accountData] of Object.entries(TEST_ACCOUNTS)) {
        // Vérifier si le compte existe déjà
        const exists = users.some(u => u.email === accountData.email);
        if (exists) {
            console.log(`[TestAccounts] Compte ${key} (${accountData.email}) existe déjà`);
            continue;
        }
        
        // Créer le compte
        const passwordHash = await hashPassword(accountData.password);
        const newUser = {
            id: Date.now() + Math.random(),
            email: accountData.email,
            passwordHash: passwordHash,
            role: accountData.role,
            shopName: accountData.shopName || '',
            createdAt: new Date().toISOString()
        };
        
        users.push(newUser);
        console.log(`[TestAccounts] ✓ Compte ${key} créé: ${accountData.email} (role: ${accountData.role})`);
    }
    
    // Sauvegarder dans localStorage
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    
    console.log('[TestAccounts] ✓ Initialisation terminée. Comptes disponibles:');
    console.table(TEST_ACCOUNTS);
}

/**\n * Affiche les comptes de test dans la console\n */\nfunction showTestAccounts() {\n    console.log('=== COMPTES DE TEST FINDSHOP ===');\n    console.table(TEST_ACCOUNTS);\n    console.log('Utilisez initTestAccounts() pour créer ces comptes.');\n}\n"