const USERS_KEY = 'findshop_users';
const AUTH_KEY = 'findshop_auth';

async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const digest = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function loadUsers() {
    try {
        const raw = localStorage.getItem(USERS_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error('Erreur lecture utilisateurs', e);
        return [];
    }
}

function saveUsers(users) {
    try {
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } catch (e) {
        console.error('Erreur sauvegarde utilisateurs', e);
    }
}

function getAuthenticatedUser() {
    try {
        return JSON.parse(localStorage.getItem(AUTH_KEY));
    } catch (e) {
        return null;
    }
}

function isAuthenticated() {
    return !!getAuthenticatedUser();
}

function requireAuth(redirect = 'login.html') {
    if (!isAuthenticated()) {
        window.location.href = redirect;
    }
}

/**
 * Vérifie que l'utilisateur connecté a le rôle requis
 * @param {string} requiredRole - Le rôle requis ('merchant' ou 'visitor')
 * @param {string} redirectUrl - L'URL de redirection si le rôle ne correspond pas
 */
function requireRole(requiredRole, redirectUrl = 'index.html') {
    const user = getAuthenticatedUser();
    
    if (!user) {
        console.warn(`[Auth] Accès refusé : pas d'utilisateur connecté. Redirection vers ${redirectUrl}`);
        window.location.href = redirectUrl;
        return;
    }
    
    if (user.role !== requiredRole) {
        console.warn(`[Auth] Accès refusé : rôle requis '${requiredRole}', utilisateur a '${user.role}'. Redirection vers ${redirectUrl}`);
        window.location.href = redirectUrl;
        return;
    }
    
    console.log(`[Auth] ✓ Accès autorisé pour le rôle '${requiredRole}'`);
}

function logout() {
    localStorage.removeItem(AUTH_KEY);
    window.location.href = 'index.html';
}

async function registerUser(email, password, role, shopName) {
    const users = loadUsers();
    const existing = users.find(user => user.email === email.toLowerCase());
    if (existing) {
        throw new Error('Cet e-mail est déjà utilisé.');
    }
    const hashed = await hashPassword(password);
    const newUser = {
        id: Date.now(),
        email: email.toLowerCase(),
        passwordHash: hashed,
        role: role || 'visitor',
        shopName: role === 'merchant' ? (shopName || '') : '',
        createdAt: new Date().toISOString()
    };
    users.push(newUser);
    saveUsers(users);
    return newUser;
}

async function loginUser(email, password) {
    const users = loadUsers();
    const user = users.find(u => u.email === email.toLowerCase());
    if (!user) {
        throw new Error('Adresse e-mail ou mot de passe invalide.');
    }
    const hashed = await hashPassword(password);
    if (hashed !== user.passwordHash) {
        throw new Error('Adresse e-mail ou mot de passe invalide.');
    }
    const authUser = {
        id: user.id,
        email: user.email,
        role: user.role || 'visitor',
        shopName: user.shopName
    };
    localStorage.setItem(AUTH_KEY, JSON.stringify(authUser));
    return authUser;
}

function updateAuthUI() {
    const authUser = getAuthenticatedUser();
    const guestLinks = document.querySelectorAll('[data-auth="guest"]');
    const userLinks = document.querySelectorAll('[data-auth="user"]');
    const userEmail = document.getElementById('headerUserEmail');

    guestLinks.forEach(el => el.classList.toggle('hidden', !!authUser));
    userLinks.forEach(el => el.classList.toggle('hidden', !authUser));
    document.querySelectorAll('.auth-link').forEach(el => el.classList.toggle('hidden', !authUser || authUser.role !== 'merchant'));

    if (userEmail) {
        userEmail.textContent = authUser ? authUser.email : '';
    }
}

function checkLogoutButtons() {
    const logoutButtons = document.querySelectorAll('.logout-btn');
    logoutButtons.forEach(btn => {
        btn.addEventListener('click', (event) => {
            event.preventDefault();
            logout();
        });
    });
}

window.addEventListener('DOMContentLoaded', () => {
    updateAuthUI();
    checkLogoutButtons();
});

if (document.readyState === 'interactive' || document.readyState === 'complete') {
    updateAuthUI();
    checkLogoutButtons();
}

window.getAuthenticatedUser = getAuthenticatedUser;
window.isAuthenticated = isAuthenticated;
window.requireAuth = requireAuth;
window.requireRole = requireRole;
window.logout = logout;
window.registerUser = registerUser;
window.loginUser = loginUser;
window.updateAuthUI = updateAuthUI;

/**
 * === COMPTES DE TEST ===
 * Utilisez ces deux comptes pour tester les redirections et les headers :
 * 
 * VISITEUR :
 * - Email: visitor@test.com
 * - Password: test1234
 * - Role: visitor
 * 
 * COMMERÇANT :
 * - Email: merchant@test.com
 * - Password: test1234
 * - Role: merchant
 */
