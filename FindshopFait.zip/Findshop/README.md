# FINDSHOP — MVP

Ce dépôt contient un MVP simple pour FINDSHOP : une plateforme pour centraliser les commerçants locaux et leurs produits.

## Structure principale

- `index.html` — Page d'accueil : recherche, filtres, liste de commerces et catalogue produits.
- `commerçant.html` — Espace commerçant : formulaire pour ajouter un produit (persisté en `localStorage`).
- `data/commerces.json` — Jeux de données initial pour les commerces et leurs produits.
- `js/` — Scripts JS du projet : `app.js`, `search.js`, `products.js`, `storage.js`, `alerts.js`.

## Fonctionnalités du MVP

- Page d'accueil responsive (Tailwind via CDN).
- Recherche textuelle et filtres (catégorie, quartier) appliqués aux commerces et au catalogue produits.
- Catalogue produit agrégé depuis `data/commerces.json` et produits ajoutés via l'espace commerçant.
- Espace commerçant (formulaire) qui sauvegarde les produits dans `localStorage` et déclenche un rafraîchissement du catalogue.
- Alertes et état de chargement (loader lors du chargement initial, bouton de soumission désactivé pendant l'ajout).

## Tester localement

Le fichier `data/commerces.json` est récupéré via `fetch()` — pour des raisons de sécurité navigateur, il faut servir les fichiers via un serveur HTTP (pas `file://`).

Méthode rapide (Python 3) :

```bash
# depuis le dossier du projet
python3 -m http.server 8000
```

Puis ouvrir `http://localhost:8000` dans votre navigateur.

## Ajouter un produit

1. Ouvrir `commerçant.html` (via le serveur HTTP ci-dessus).
2. Remplir le formulaire et cliquer sur `Ajouter`.
3. Le produit sera stocké dans `localStorage` (clé `findshop_products`) et le catalogue sur `index.html` se mettra à jour automatiquement (événement `product:added`).

## Notes de développement

- Le code est volontairement simple et sans bundler pour accélérer le prototypage.
- Pour passer à une vraie API : remplacer la logique `localStorage` par des appels `fetch()` vers un serveur Node/Express.

Si tu veux, je peux maintenant :
- Lier chaque produit ajouté à un commerce existant (sélection dans le formulaire).
- Ajouter pagination ou tri dans le catalogue.
- Mettre en place un petit serveur Node/Express pour remplacer le stockage local.

Que souhaites-tu que j'implémente ensuite ?
