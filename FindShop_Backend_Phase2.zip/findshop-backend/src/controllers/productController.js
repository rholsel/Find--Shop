const { z }     = require('zod');
const { getDb } = require('../config/database');

// ── Schémas ──────────────────────────────────────────────────────────────────

const ProductSchema = z.object({
  nom:         z.string().min(2, 'Nom du produit trop court.'),
  description: z.string().optional().nullable(),
  prix:        z.coerce.number().positive('Le prix doit être supérieur à 0.'),
  categorie:   z.string().optional().nullable(),
  commerce_id: z.coerce.number().int().positive('commerce_id invalide.'),
});

// ── Helpers ──────────────────────────────────────────────────────────────────

function buildImageUrl(req, filename) {
  if (!filename) return null;
  if (filename.startsWith('http')) return filename;
  return `${req.protocol}://${req.get('host')}/uploads/${filename}`;
}

// ── Contrôleurs ──────────────────────────────────────────────────────────────

/** GET /api/products  (optionnel: ?commerce_id=X&categorie=Y&q=nom) */
function listProducts(req, res) {
  const db = getDb();
  const { commerce_id, categorie, q } = req.query;

  let sql    = 'SELECT p.*, c.nom as commerce_nom, c.quartier as commerce_quartier FROM products p LEFT JOIN commerces c ON c.id = p.commerce_id WHERE 1=1';
  const args = [];

  if (commerce_id) { sql += ' AND p.commerce_id = ?'; args.push(commerce_id); }
  if (categorie)   { sql += ' AND p.categorie   = ?'; args.push(categorie);   }
  if (q)           { sql += ' AND (p.nom LIKE ? OR p.description LIKE ?)'; args.push(`%${q}%`, `%${q}%`); }

  sql += ' ORDER BY p.created_at DESC';

  const products = db.prepare(sql).all(...args).map(p => ({
    ...p,
    image: buildImageUrl(req, p.image),
  }));

  return res.json(products);
}

/** GET /api/products/:id */
function getProduct(req, res) {
  const db = getDb();
  const p  = db.prepare(`
    SELECT p.*, c.nom as commerce_nom, c.quartier as commerce_quartier
    FROM products p LEFT JOIN commerces c ON c.id = p.commerce_id
    WHERE p.id = ?
  `).get(req.params.id);

  if (!p) return res.status(404).json({ error: 'Produit introuvable.' });
  return res.json({ ...p, image: buildImageUrl(req, p.image) });
}

/** POST /api/products  (marchand authentifié) */
function createProduct(req, res) {
  const parsed = ProductSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const d  = parsed.data;
  const db = getDb();

  // Vérifier que le commerce appartient au marchand
  const commerce = db.prepare('SELECT * FROM commerces WHERE id = ?').get(d.commerce_id);
  if (!commerce) return res.status(404).json({ error: 'Commerce introuvable.' });
  if (commerce.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Vous ne pouvez ajouter des produits qu\'à votre propre commerce.' });
  }

  const imageFile = req.file ? req.file.filename : null;

  const result = db.prepare(`
    INSERT INTO products (nom, description, prix, categorie, image, commerce_id, created_by)
    VALUES (?,?,?,?,?,?,?)
  `).run(
    d.nom, d.description ?? null, d.prix, d.categorie ?? null,
    imageFile, d.commerce_id, req.user.id
  );

  const p = db.prepare(`
    SELECT p.*, c.nom as commerce_nom, c.quartier as commerce_quartier
    FROM products p LEFT JOIN commerces c ON c.id = p.commerce_id
    WHERE p.id = ?
  `).get(result.lastInsertRowid);

  return res.status(201).json({ ...p, image: buildImageUrl(req, p.image) });
}

/** PUT /api/products/:id */
function updateProduct(req, res) {
  const db = getDb();
  const p  = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Produit introuvable.' });

  if (p.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Modification non autorisée.' });
  }

  const parsed = ProductSchema.partial().omit({ commerce_id: true }).safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const d         = parsed.data;
  const imageFile = req.file ? req.file.filename : undefined;

  const fields = { ...d, updated_at: new Date().toISOString() };
  if (imageFile !== undefined) fields.image = imageFile;

  const sets = Object.keys(fields).map(k => `${k} = ?`).join(', ');
  const vals = [...Object.values(fields), req.params.id];
  db.prepare(`UPDATE products SET ${sets} WHERE id = ?`).run(...vals);

  const updated = db.prepare(`
    SELECT p.*, c.nom as commerce_nom, c.quartier as commerce_quartier
    FROM products p LEFT JOIN commerces c ON c.id = p.commerce_id
    WHERE p.id = ?
  `).get(req.params.id);

  return res.json({ ...updated, image: buildImageUrl(req, updated.image) });
}

/** DELETE /api/products/:id */
function deleteProduct(req, res) {
  const db = getDb();
  const p  = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Produit introuvable.' });

  if (p.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Suppression non autorisée.' });
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  return res.json({ message: 'Produit supprimé.' });
}

module.exports = { listProducts, getProduct, createProduct, updateProduct, deleteProduct };
