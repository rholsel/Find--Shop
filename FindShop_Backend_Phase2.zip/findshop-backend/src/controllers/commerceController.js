const { z }     = require('zod');
const { getDb } = require('../config/database');

// ── Schémas ──────────────────────────────────────────────────────────────────

const CommerceSchema = z.object({
  nom:         z.string().min(2, 'Nom trop court.'),
  description: z.string().optional().nullable(),
  categorie:   z.string().optional().nullable(),
  quartier:    z.string().optional().nullable(),
  adresse:     z.string().optional().nullable(),
  telephone:   z.string().optional().nullable(),
  horaires:    z.string().optional().nullable(),
  latitude:    z.coerce.number().optional().nullable(),
  longitude:   z.coerce.number().optional().nullable(),
});

// ── Helpers ──────────────────────────────────────────────────────────────────

function buildImageUrl(req, filename) {
  if (!filename) return null;
  if (filename.startsWith('http')) return filename;
  return `${req.protocol}://${req.get('host')}/uploads/${filename}`;
}

function formatCommerce(c, req) {
  return {
    ...c,
    lat: c.latitude,
    lon: c.longitude,
    image: buildImageUrl(req, c.image),
  };
}

// ── Contrôleurs ──────────────────────────────────────────────────────────────

/** GET /api/commerces */
function listCommerces(req, res) {
  const db = getDb();
  const { categorie, quartier, q } = req.query;

  let sql    = 'SELECT * FROM commerces WHERE 1=1';
  const args = [];

  if (categorie) { sql += ' AND categorie = ?'; args.push(categorie); }
  if (quartier)  { sql += ' AND quartier  = ?'; args.push(quartier);  }
  if (q)         { sql += ' AND (nom LIKE ? OR description LIKE ?)'; args.push(`%${q}%`, `%${q}%`); }

  sql += ' ORDER BY created_at DESC';

  const commerces = db.prepare(sql).all(...args);

  // Enrichir avec les produits
  const getProds = db.prepare('SELECT * FROM products WHERE commerce_id = ? ORDER BY created_at DESC');

  const result = commerces.map(c => ({
    ...formatCommerce(c, req),
    produits: getProds.all(c.id).map(p => ({
      ...p,
      image: buildImageUrl(req, p.image),
    })),
  }));

  return res.json(result);
}

/** GET /api/commerces/:id */
function getCommerce(req, res) {
  const db = getDb();
  const c  = db.prepare('SELECT * FROM commerces WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Commerce introuvable.' });

  const produits = db.prepare('SELECT * FROM products WHERE commerce_id = ? ORDER BY created_at DESC').all(c.id)
    .map(p => ({ ...p, image: buildImageUrl(req, p.image) }));

  return res.json({ ...formatCommerce(c, req), produits });
}

/** POST /api/commerces  (marchand authentifié) */
function createCommerce(req, res) {
  const parsed = CommerceSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const d  = parsed.data;
  const db = getDb();
  const imageFile = req.file ? req.file.filename : null;

  const result = db.prepare(`
    INSERT INTO commerces
      (nom, description, categorie, quartier, adresse, telephone, horaires, latitude, longitude, image, created_by)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    d.nom, d.description ?? null, d.categorie ?? null, d.quartier ?? null,
    d.adresse ?? null, d.telephone ?? null, d.horaires ?? null,
    d.latitude ?? null, d.longitude ?? null,
    imageFile, req.user.id
  );

  const c = db.prepare('SELECT * FROM commerces WHERE id = ?').get(result.lastInsertRowid);
  return res.status(201).json({ ...formatCommerce(c, req), produits: [] });
}

/** PUT /api/commerces/:id */
function updateCommerce(req, res) {
  const db = getDb();
  const c  = db.prepare('SELECT * FROM commerces WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Commerce introuvable.' });

  // Seul le propriétaire peut modifier
  if (c.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Modification non autorisée.' });
  }

  const parsed = CommerceSchema.partial().safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const d         = parsed.data;
  const imageFile = req.file ? req.file.filename : undefined;

  const fields = { ...d, updated_at: new Date().toISOString() };
  if (imageFile !== undefined) fields.image = imageFile;

  const sets = Object.keys(fields).map(k => `${k} = ?`).join(', ');
  const vals = [...Object.values(fields), req.params.id];

  db.prepare(`UPDATE commerces SET ${sets} WHERE id = ?`).run(...vals);

  const updated  = db.prepare('SELECT * FROM commerces WHERE id = ?').get(req.params.id);
  const produits = db.prepare('SELECT * FROM products WHERE commerce_id = ?').all(req.params.id)
    .map(p => ({ ...p, image: buildImageUrl(req, p.image) }));

  return res.json({ ...formatCommerce(updated, req), produits });
}

/** DELETE /api/commerces/:id */
function deleteCommerce(req, res) {
  const db = getDb();
  const c  = db.prepare('SELECT * FROM commerces WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Commerce introuvable.' });

  if (c.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Suppression non autorisée.' });
  }

  db.prepare('DELETE FROM commerces WHERE id = ?').run(req.params.id);
  return res.json({ message: 'Commerce supprimé.' });
}

module.exports = { listCommerces, getCommerce, createCommerce, updateCommerce, deleteCommerce };
