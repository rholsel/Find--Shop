const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { z }   = require('zod');
const { getDb } = require('../config/database');

const JWT_SECRET  = process.env.JWT_SECRET  || 'findshop_secret';
const JWT_EXPIRES = process.env.JWT_EXPIRES_IN || '7d';

// ── Schémas de validation ────────────────────────────────────────────────────

const RegisterSchema = z.object({
  email:     z.string().email('Email invalide.'),
  password:  z.string().min(6, 'Le mot de passe doit contenir au moins 6 caractères.'),
  role:      z.enum(['visitor', 'merchant'], { errorMap: () => ({ message: 'Rôle invalide.' }) }),
  shop_name: z.string().min(2).optional().nullable(),
});

const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(1, 'Mot de passe requis.'),
});

// ── Helpers ──────────────────────────────────────────────────────────────────

function makeToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, shop_name: user.shop_name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
}

function safeUser(u) {
  const { password, ...rest } = u;
  return rest;
}

// ── Contrôleurs ──────────────────────────────────────────────────────────────

/**
 * POST /api/auth/register
 */
function register(req, res) {
  const parsed = RegisterSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const { email, password, role, shop_name } = parsed.data;
  const db = getDb();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'Cet email est déjà utilisé.' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare(
    'INSERT INTO users (email, password, role, shop_name) VALUES (?,?,?,?)'
  ).run(email, hash, role, shop_name || null);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
  const token = makeToken(user);

  return res.status(201).json({ token, user: safeUser(user) });
}

/**
 * POST /api/auth/login
 */
function login(req, res) {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors[0].message });
  }

  const { email, password } = parsed.data;
  const db = getDb();

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
  }

  const valid = bcrypt.compareSync(password, user.password);
  if (!valid) {
    return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
  }

  const token = makeToken(user);
  return res.json({ token, user: safeUser(user) });
}

/**
 * GET /api/auth/me
 */
function me(req, res) {
  const db   = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  return res.json({ user: safeUser(user) });
}

module.exports = { register, login, me };
