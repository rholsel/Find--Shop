/**
 * seed.js – peuple la base de données avec les données initiales de commerces.json
 * Usage : node src/config/seed.js
 */
require('dotenv').config();
const { getDb } = require('./database');
const bcrypt = require('bcryptjs');

const COMMERCES_INITIALES = [
  {
    nom: 'Marché Central',
    categorie: 'Alimentation',
    quartier: 'Centre-ville',
    description: 'Grand marché local spécialisé dans les produits frais, les fruits, légumes et épicerie de terroir.',
    telephone: '+243 999 000 111',
    adresse: '12 Rue du Marché, Centre-ville, 1000',
    latitude: -4.325,
    longitude: 15.322,
    horaires: 'Lundi à Samedi : 8h00 - 19h00',
    image: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9',
    produits: [
      { nom: 'Tomates',  prix: 2,  image: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce' },
      { nom: 'Pommes',   prix: 3,  image: 'https://images.unsplash.com/photo-1574226516831-e1dff420e12b' },
    ],
  },
  {
    nom: 'Tech Store',
    categorie: 'Electronique',
    quartier: 'Golf',
    description: 'Boutique high-tech proposant smartphones, ordinateurs portables, accessoires et services de réparation.',
    telephone: '+243 999 222 333',
    adresse: '54 Avenue des Technologies, Golf, 1000',
    latitude: -4.321,
    longitude: 15.334,
    horaires: 'Lundi à Vendredi : 10h00 - 19h30, Samedi : 10h00 - 17h00',
    image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c',
    produits: [
      { nom: 'Samsung A55', prix: 350, image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9' },
      { nom: 'Power Bank',  prix: 25,  image: 'https://images.unsplash.com/photo-1510557880182-3c5a6c9fada3' },
    ],
  },
  {
    nom: 'Boutique Mode Élégance',
    categorie: 'Mode',
    quartier: 'Bel-Air',
    description: 'Vêtements et accessoires de mode pour toute la famille.',
    telephone: '+243 999 444 555',
    adresse: '8 Boulevard de la Mode, Bel-Air, 1000',
    latitude: -4.330,
    longitude: 15.318,
    horaires: 'Tous les jours : 9h00 - 20h00',
    image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04',
    produits: [
      { nom: 'Robe d\'été', prix: 45, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446' },
      { nom: 'Sac à main', prix: 30, image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa' },
    ],
  },
];

async function seed() {
  const db = getDb();

  // Comptes de démonstration
  const demoUsers = [
    { email: 'visitor@test.com',  password: 'test1234', role: 'visitor',  shop_name: null },
    { email: 'merchant@test.com', password: 'test1234', role: 'merchant', shop_name: 'Marché Central' },
  ];

  console.log('🌱  Insertion des utilisateurs de démonstration...');
  const insertUser = db.prepare(
    'INSERT OR IGNORE INTO users (email, password, role, shop_name) VALUES (?,?,?,?)'
  );

  for (const u of demoUsers) {
    const hash = bcrypt.hashSync(u.password, 10);
    insertUser.run(u.email, hash, u.role, u.shop_name);
  }

  // Récupérer l'ID du marchand pour lier les commerces
  const merchant = db.prepare('SELECT id FROM users WHERE email = ?').get('merchant@test.com');

  console.log('🌱  Insertion des commerces initiaux...');
  const insertCommerce = db.prepare(`
    INSERT OR IGNORE INTO commerces
      (nom, categorie, quartier, description, telephone, adresse, latitude, longitude, horaires, image, created_by)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `);

  const insertProduct = db.prepare(`
    INSERT INTO products (nom, prix, image, categorie, commerce_id, created_by)
    VALUES (?,?,?,?,?,?)
  `);

  const existingCount = db.prepare('SELECT COUNT(*) as c FROM commerces').get().c;
  if (existingCount === 0) {
    for (const c of COMMERCES_INITIALES) {
      const res = insertCommerce.run(
        c.nom, c.categorie, c.quartier, c.description,
        c.telephone, c.adresse, c.latitude, c.longitude,
        c.horaires, c.image, merchant.id
      );
      const cId = res.lastInsertRowid;
      for (const p of (c.produits || [])) {
        insertProduct.run(p.nom, p.prix, p.image, c.categorie, cId, merchant.id);
      }
    }
    console.log(`✅  ${COMMERCES_INITIALES.length} commerces insérés avec leurs produits.`);
  } else {
    console.log(`ℹ️  Base déjà peuplée (${existingCount} commerces). Seed ignoré.`);
  }

  console.log('✅  Seed terminé.');
}

seed().catch(err => { console.error(err); process.exit(1); });
